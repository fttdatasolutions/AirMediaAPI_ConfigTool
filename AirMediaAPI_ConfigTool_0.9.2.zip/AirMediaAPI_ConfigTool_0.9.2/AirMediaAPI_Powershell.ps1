import-module pscrestron -usewindowspowershell

# set target_ip and filepath as mandatory parameters when invoking this script

param(
    [Parameter(Mandatory=$true)]
    [string]$target_ip
)
param(
    [Parameter(Mandatory=$true)]
    [string]$filepath
)

# Update Firmware
update-puf -device $target_ip -path $filepath -secure -username "example" -password "example" -ShowProgress;

# Reboot
invoke-crestroncommand -device $target_ip -secure -username "example" -password "example" -command "reboot";